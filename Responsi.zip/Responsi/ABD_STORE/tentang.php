<div class="hdproduk">
Tentang Kami
</div>
<div class="jumbotron">
<div style="margin-left:50px;">
<p>Toko buku online terbesar dan terlengkap di Indonesia,dengan harga yang jauh<br> lebih murah dari toko buku lainnya.</p>
    <p>jl Kuniran raya Baron Nganjuk</p>
    <p>kode pos : 64394</p>
    <p>Telp : (0314) 453 526</p>
    <p>WA : 085853480591</p>
    <p>BBM : 6746GGA</p>
    </div>
</div>