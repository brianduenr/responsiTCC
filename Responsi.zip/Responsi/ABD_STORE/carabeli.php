<div class="hdproduk">
Cara Beli
</div>
<div class="jumbotron">
   <p style="margin-left:50px;"> Detail buku => tambah ke keranjang =>chekout => bayar =>konfirmasi bayar => dikirim =>diterima => konfirmasi terima =>selesai
</p>
</div>