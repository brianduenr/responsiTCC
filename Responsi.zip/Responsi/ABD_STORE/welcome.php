<div class="jumbotron">
	<div class="row">
	<div class="col-md-3">
	<img src="img/buku.png">
	</div>
	<div class="col-md-8">
    <h1>Bakolbuku.com</h1>
    <p class="lead">Toko buku online terbesar dan terlengkap di Indonesia,dengan harga yang jauh lebih murah dari toko buku lainnya.</p>
    <p><a class="btn btn-lg btn-success" href="#" role="button">Beli Sekarang</a></p>
    </div>
    </div>
</div>